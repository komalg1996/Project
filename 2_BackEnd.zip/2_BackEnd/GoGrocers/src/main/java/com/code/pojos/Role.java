package com.code.pojos;

public enum Role {

	ADMIN,EMPLOYEE,CUSTOMER,DELIVERY_PERSON;
}
