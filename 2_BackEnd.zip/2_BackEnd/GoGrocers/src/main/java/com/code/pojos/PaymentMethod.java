package com.code.pojos;

public enum PaymentMethod {
	CARD,CASHONDELIVERY,UPI,NETBANKING
}
