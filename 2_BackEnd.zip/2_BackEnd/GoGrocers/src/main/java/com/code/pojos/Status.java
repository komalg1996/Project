package com.code.pojos;

public enum Status {
	ACTIVE, INACTIVE
}
