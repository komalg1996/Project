package com.code.pojos;

public enum PaymentStatus {
	PENDING, COMPLETED, REFUNDED
}
